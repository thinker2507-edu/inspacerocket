#pragma once
#include <stdint.h>
#include <stddef.h>
// Plantower PMS5003 manual V2.3, Appendix I: 32-byte active frame, 42 4D,
// big-endian length28, additive checksum of bytes0..29.
struct Pms5003Frame {
  uint8_t bytes[32]={};size_t used=0;
  uint16_t standard[3]={},atmospheric[3]={},particles[6]={};
  uint32_t good=0,bad=0;
  constexpr uint16_t word(size_t i)const{return (uint16_t(bytes[i])<<8)|bytes[i+1];}
  constexpr void resync(){
    size_t start=1;
    for(;start<used;++start)if(bytes[start]==0x42 && (start+1==used || bytes[start+1]==0x4D))break;
    size_t n=used-start;for(size_t i=0;i<n;++i)bytes[i]=bytes[start+i];used=n;
  }
  constexpr bool feed(uint8_t byte){
    if(!used && byte!=0x42)return false;
    bytes[used++]=byte;
    if(used==2 && bytes[1]!=0x4D){resync();return false;}
    if(used>=4 && word(2)!=28){++bad;resync();return false;}
    if(used<32)return false;
    uint16_t sum=0;for(unsigned i=0;i<30;++i)sum+=bytes[i];
    if(sum!=word(30)){++bad;resync();return false;}
    for(unsigned i=0;i<3;++i){standard[i]=word(4+i*2);atmospheric[i]=word(10+i*2);}
    for(unsigned i=0;i<6;++i)particles[i]=word(16+i*2);
    ++good;used=0;return true;
  }
};
