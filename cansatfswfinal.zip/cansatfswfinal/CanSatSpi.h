#pragma once
#include <Arduino.h>
#include <SPI.h>
#include "CanSatPins.h"

// Only the synchronous main loop owns this SPI bus. The radio has no wired
// DIO1 in the pinout and is polled; no ISR/task may access SPI concurrently.
// Radio and flash now share SCK18/MISO19/MOSI23 with separate CS5/CS4.
// Initialize once: never stop/rebind the bus between flash and radio operations.
namespace CanSatSpi {
enum Profile { NONE, RADIO, FLASH };
inline Profile active=NONE;
inline void select(Profile profile){
  if(active==profile)return;
  digitalWrite(CanSatPins::RADIO_CS,HIGH);digitalWrite(CanSatPins::FLASH_CS,HIGH);
  if(active==NONE)SPI.begin(CanSatPins::SCK_PIN,
    CanSatPins::RADIO_MISO,CanSatPins::RADIO_MOSI,-1);
  active=profile;
}
struct FlashScope {
  FlashScope(){select(FLASH);SPI.beginTransaction(SPISettings(10000000,MSBFIRST,SPI_MODE0));}
  ~FlashScope(){SPI.endTransaction();select(RADIO);}
};
}
