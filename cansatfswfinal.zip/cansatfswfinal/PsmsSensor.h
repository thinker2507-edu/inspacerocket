#pragma once
#include <stdint.h>
#include <stdio.h>
#include "Pms5003Frame.h"
#if defined(ARDUINO_ARCH_ESP32)
#include <HardwareSerial.h>
#include "CanSatPins.h"
#endif
class PsmsSensor {
public:
  enum Status : uint8_t { UNCONFIGURED=0, INITIALIZING=1, VALID=2, STALE=3, FAULT=4, WARMING=5 };
  Pms5003Frame frame;
  void begin(){
#if defined(ARDUINO_ARCH_ESP32)
    serial.begin(9600,SERIAL_8N1,CanSatPins::PMS_RX,CanSatPins::PMS_TX);
    started=millis();state=INITIALIZING;
#endif
  }
  void service(uint32_t now){
#if defined(ARDUINO_ARCH_ESP32)
    if(frame.used && uint32_t(now-lastByte)>250){frame.used=0;++frame.bad;}
    for(unsigned budget=0;budget<64 && serial.available();++budget){
      lastByte=now;
      if(frame.feed(uint8_t(serial.read()))){
        if(!haveSample || uint32_t(now-lastGood)>5000)warmSince=now;
        haveSample=true;lastGood=now;
      }
    }
    if(!haveSample)state=frame.bad?FAULT:uint32_t(now-started)>5000?STALE:INITIALIZING;
    else if(uint32_t(now-lastGood)>5000)state=STALE;
    else state=uint32_t(now-warmSince)<30000?WARMING:VALID;
#else
    (void)now;
#endif
  }
  Status status()const{return state;}
  void statusText(char* out,size_t capacity)const{
    if(state==VALID)snprintf(out,capacity,"PMS=PMS5003;S=2;RX=26;TX=27;BAUD=9600;PM1=%u;PM25=%u;PM10=%u;UNIT=UGM3;BAD=%lu",
      unsigned(frame.atmospheric[0]),unsigned(frame.atmospheric[1]),unsigned(frame.atmospheric[2]),(unsigned long)frame.bad);
    else snprintf(out,capacity,"PMS=PMS5003;S=%u;RX=26;TX=27;BAUD=9600;PM1=NA;PM25=NA;PM10=NA;BAD=%lu",
      unsigned(state),(unsigned long)frame.bad);
  }
  int telemetryExtras(char* out,size_t capacity)const{
    if(state==VALID)return snprintf(out,capacity,";PMS=2;PM1=%u;PM25=%u;PM10=%u",
      unsigned(frame.atmospheric[0]),unsigned(frame.atmospheric[1]),unsigned(frame.atmospheric[2]));
    return snprintf(out,capacity,";PMS=%u",unsigned(state));
  }
private:
  Status state=UNCONFIGURED;
#if defined(ARDUINO_ARCH_ESP32)
  HardwareSerial serial{2};
#endif
  uint32_t started=0,lastGood=0,lastByte=0,warmSince=0;
  bool haveSample=false;
};