#pragma once
// Source: three images in ../pinouts_for_cansat (2026-10-26).
namespace CanSatPins {
constexpr int SDA_PIN=21,SCL_PIN=22,SCK_PIN=18;
constexpr int RADIO_CS=5,RADIO_RESET=12,RADIO_BUSY=13;
// Developer correction: radio and flash share standard ESP32 MISO19/MOSI23.
constexpr int RADIO_MISO=19,RADIO_MOSI=23;
constexpr int FLASH_CS=4,FLASH_MISO=19,FLASH_MOSI=23;
static_assert(RADIO_MISO==FLASH_MISO && RADIO_MOSI==FLASH_MOSI,
              "Radio and flash share one fixed SPI data-pin mapping");
constexpr int PMS_RX=26,PMS_TX=27;
constexpr unsigned MPU_ADDRESS=0x69; // AD0 must be physically tied to 3.3 V
// Developer confirms no GPS and no SD installed. Do not assign their peripherals.
}
