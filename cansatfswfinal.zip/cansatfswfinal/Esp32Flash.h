#pragma once
#include "CanSatSpi.h"
#ifndef FLIGHT_FLASH_ENABLED
#define FLIGHT_FLASH_ENABLED 1
#endif
// Developer confirmed W25Q64JV8MiB on2026-10-26: image "64MB" means64Mbit.
// Fail closed on any other JEDEC; never configure/erase an unidentified chip.
#ifndef FLIGHT_FLASH_JEDEC
#define FLIGHT_FLASH_JEDEC 0xEF4017UL
#endif
#ifndef FLIGHT_FLASH_BYTES
#define FLIGHT_FLASH_BYTES (8UL*1024UL*1024UL)
#endif
static_assert(FLIGHT_FLASH_BYTES<=0x1000000UL,"24-bit addressing only; identify larger flash first");
struct FlashHardware {
  bool enabled=false;uint32_t detectedId=0;uint8_t chipSelect=CanSatPins::FLASH_CS;
  uint32_t size()const{return FLIGHT_FLASH_BYTES;}
  uint8_t status(){SPI.transfer(0x05);return SPI.transfer(0);}
  bool begin(uint8_t cs){
    chipSelect=cs;pinMode(cs,OUTPUT);digitalWrite(cs,HIGH);
#if FLIGHT_FLASH_ENABLED
    CanSatSpi::FlashScope scope;
    digitalWrite(cs,LOW);SPI.transfer(0x9F);
    uint32_t id=0;for(unsigned i=0;i<3;++i)id=(id<<8)|SPI.transfer(0);
    digitalWrite(cs,HIGH);detectedId=id;
    enabled=id==FLIGHT_FLASH_JEDEC && id==0xEF4017UL && size()<=8UL*1024UL*1024UL;
#endif
    return enabled;
  }
  bool ready(){
    if(!enabled)return false;
    CanSatSpi::FlashScope scope;digitalWrite(chipSelect,LOW);
    const uint8_t s=status();digitalWrite(chipSelect,HIGH);return !(s&1);
  }
  // W25Q64JV datasheet: WREN06 + Chip EraseC7; WIP polled by maintenance.
  // No status/protection register is changed to force an erase through.
  bool startChipErase(){
#if FLIGHT_FLASH_ENABLED
    if(!enabled || size()!=8UL*1024UL*1024UL || !ready())return false;
    CanSatSpi::FlashScope scope;
    digitalWrite(chipSelect,LOW);SPI.transfer(0x9F);
    uint32_t id=0;for(unsigned i=0;i<3;++i)id=(id<<8)|SPI.transfer(0);
    digitalWrite(chipSelect,HIGH);
    if(id!=0xEF4017UL || id!=FLIGHT_FLASH_JEDEC)return false;
    digitalWrite(chipSelect,LOW);uint8_t s=status();digitalWrite(chipSelect,HIGH);
    if(s&0x1D)return false; // WIP or any BP protection bit set
    digitalWrite(chipSelect,LOW);SPI.transfer(0x06);digitalWrite(chipSelect,HIGH);
    digitalWrite(chipSelect,LOW);s=status();digitalWrite(chipSelect,HIGH);
    if(!(s&2))return false;
    digitalWrite(chipSelect,LOW);SPI.transfer(0xC7);digitalWrite(chipSelect,HIGH);
    return true; // acceptance alone is not completion; verify every byte later
#else
    return false;
#endif
  }
  void address(uint32_t a){SPI.transfer(uint8_t(a>>16));SPI.transfer(uint8_t(a>>8));SPI.transfer(uint8_t(a));}
  bool read(uint32_t a,void* data,uint32_t n){
    if(!ready() || uint64_t(a)+n>size())return false;
    CanSatSpi::FlashScope scope;digitalWrite(chipSelect,LOW);SPI.transfer(0x03);address(a);
    auto out=static_cast<uint8_t*>(data);for(uint32_t i=0;i<n;++i)out[i]=SPI.transfer(0);
    digitalWrite(chipSelect,HIGH);return true;
  }
  bool program(uint32_t a,const void* data,uint32_t n){
    if(!ready() || !n || n>128 || uint64_t(a)+n>size() || (a&255)+n>256)return false;
    CanSatSpi::FlashScope scope;
    digitalWrite(chipSelect,LOW);SPI.transfer(0x06);digitalWrite(chipSelect,HIGH);
    digitalWrite(chipSelect,LOW);const uint8_t s=status();digitalWrite(chipSelect,HIGH);
    if(!(s&2))return false;
    digitalWrite(chipSelect,LOW);SPI.transfer(0x02);address(a);
    auto in=static_cast<const uint8_t*>(data);for(uint32_t i=0;i<n;++i)SPI.transfer(in[i]);
    digitalWrite(chipSelect,HIGH);return true; // journal later checks WIP/readback/commit
  }
};
