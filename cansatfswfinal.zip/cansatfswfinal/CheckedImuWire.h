#pragma once
#include <Wire.h>

// ESP32-only facade for MPU6500_WE1.2.17. Uses the already initialized Wire;
// never starts a second I2C controller or changes pins/clock. The library does
// not check transfer lengths and can otherwise decode uninitialized stack bytes.
// On failure, provide initialized padding, latch the fault and suppress further
// bus IO in that operation. The adapter MUST discard all values if error!=0.
struct CheckedImuWire : TwoWire {
  TwoWire& bus;
  uint8_t error=0,errorRegister=0,reg=0;
  size_t remaining=0;
  bool firstByte=true,padding=false,txOpen=false;
  explicit CheckedImuWire(TwoWire& upstream):TwoWire(0),bus(upstream){}
  void clear(){error=errorRegister=0;remaining=0;padding=false;}
  void fail(uint8_t code){if(!error){error=code;errorRegister=reg;}}
  void beginTransmission(uint8_t address)override{
    firstByte=true;if(!error){bus.beginTransmission(address);txOpen=true;}
  }
  size_t write(uint8_t value)override{
    if(firstByte){reg=value;firstByte=false;}
    if(error)return 0;
    const size_t n=bus.write(value);if(n!=1)fail(254);return n;
  }
  size_t write(const uint8_t* data,size_t n)override{
    size_t done=0;while(done<n && write(data[done])==1)++done;return done;
  }
  uint8_t endTransmission(bool stop)override{
    if(!txOpen)return error;
    txOpen=false;
    // A failed write must still finish/release Wire's transaction/mutex.
    const uint8_t code=bus.endTransmission(error?true:stop);
    if(code)fail(code);return error?error:code;
  }
  uint8_t endTransmission()override{return endTransmission(true);}
  size_t requestFrom(uint8_t address,size_t n,bool stop)override{
    const size_t got=error?0:bus.requestFrom(address,n,stop);
    remaining=n;padding=got!=n;
    if(padding){fail(255);while(bus.available())bus.read();}
    return got;
  }
  size_t requestFrom(uint8_t address,size_t n)override{return requestFrom(address,n,true);}
  int available()override{return int(remaining);}
  int read()override{
    if(!remaining)return -1;
    --remaining;if(padding)return 0;
    const int value=bus.read();if(value<0){fail(255);padding=true;return 0;}return value;
  }
  int peek()override{return !remaining?-1:padding?0:bus.peek();}
};
