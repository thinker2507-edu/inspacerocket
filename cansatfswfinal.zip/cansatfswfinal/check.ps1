param([string]$ArduinoData="$env:LOCALAPPDATA\Arduino15",[string]$ArduinoLibraries="$env:USERPROFILE\Documents\Arduino\libraries")
$ErrorActionPreference='Stop'
$espCore=Join-Path $ArduinoData 'packages/esp32/hardware/esp32/3.3.12'
$espSdk=Join-Path $ArduinoData 'packages/esp32/tools/esp32-libs/3.3.12'
$compiler=Join-Path $ArduinoData 'packages/esp32/tools/esp-x32/2601/bin/xtensa-esp32-elf-g++.exe'
if(!(Test-Path -LiteralPath $compiler)){throw 'Installed ESP32 compiler not found; build using Arduino IDE.'}
$flags=@("@$espSdk/flags/cpp_flags","@$espSdk/flags/defines",'-iprefix',"$espSdk/include/","@$espSdk/flags/includes","-I$espSdk/qio_qspi/include","-I$espCore/cores/esp32","-I$espCore/variants/esp32","-I$espCore/libraries/Wire/src","-I$espCore/libraries/SPI/src","-I$ArduinoLibraries/RadioLib/src","-I$ArduinoLibraries/SparkFun_BMP581_Arduino_Library/src","-I$ArduinoLibraries/RTClib/src","-I$ArduinoLibraries/Adafruit_BusIO","-I$ArduinoLibraries/MPU9250_WE/src",'-DESP32','-DARDUINO=10819','-DARDUINO_ARCH_ESP32','-DARDUINO_ESP32_DEV','-DF_CPU=240000000','-DARDUINO_USB_CDC_ON_BOOT=0','-include','Arduino.h','-x','c++','-Wall','-Wextra','-Wformat=2','-c')
$pmsFlags=@("@$espSdk/flags/cpp_flags","@$espSdk/flags/defines",'-iprefix',"$espSdk/include/","@$espSdk/flags/includes","-I$espSdk/qio_qspi/include",'-std=gnu++20','-fsyntax-only','-Wall','-Wextra','-Werror')
& $compiler @pmsFlags (Join-Path (Split-Path $PSScriptRoot -Parent) 'tests/cansat-pms.cpp')
if($LASTEXITCODE -ne 0){throw 'PMS5003 frame assertions failed'}
Write-Output 'PASS: actual PMS5003 frame checksum, field mapping, malformed/partial/resynchronization assertions.'
$object=Join-Path $PSScriptRoot 'cansat-check.o'
try {
  & $compiler @flags (Join-Path $PSScriptRoot 'cansatfswfinal.ino') -o $object
  if($LASTEXITCODE -ne 0){throw 'ESP32 CanSat object compilation failed'}
  & $compiler @flags -DFLIGHT_FLASH_ENABLED=0 (Join-Path $PSScriptRoot 'cansatfswfinal.ino') -o $object
  if($LASTEXITCODE -ne 0){throw 'ESP32 CanSat disabled-flash object compilation failed'}
  foreach($librarySource in @('MPU6500_WE.cpp','xyzFloat.cpp')){
    & $compiler @flags (Join-Path $ArduinoLibraries ('MPU9250_WE/src/'+$librarySource)) -o $object
    if($LASTEXITCODE -ne 0){throw "MPU9250_WE dependency compilation failed: $librarySource"}
  }
} finally {if(Test-Path -LiteralPath $object){Remove-Item -LiteralPath $object}}
Write-Output 'PASS: independent CanSat ESP32 objects with flash enabled/disabled; installed core3.3.12. No linked image, upload or hardware validation.'