#pragma once
#include <Wire.h>
#include <math.h>
#include "CanSatPins.h"
#include <MPU6500_WE.h>
#include "CheckedImuWire.h"

// Existing FSW adapter, now using the developer's working MPU6500_WE library.
// Flight ranges retained explicitly:100Hz,+/-16g,+/-2000deg/s. Library g values
// are converted to m/s2; existing persistent FSW calibration is applied once.
// No fabricated SH-2 reports or sensor-provided calibration accuracy values.
struct FlightMpuLibrary : MPU6500_WE {
  FlightMpuLibrary(TwoWire* bus,uint8_t address):MPU6500_WE(bus,address){}
  bool initialize(uint8_t identity){return init(identity);}
};
struct Mpu6050 {
  CheckedImuWire libraryBus{Wire};
  FlightMpuLibrary sensor{&libraryBus,CanSatPins::MPU_ADDRESS};
  bool present=false,gravityReady=false;
  // stage:0 untried,1 ID read failed,2 unsupported ID,3 config write failed,
  // 4 initialized,5 runtime sample fault. I2C=255 means a short read.
  uint8_t whoAmI=0,lastRegister=0,wireError=0,initStage=0;
  const char* modelName()const{
    if(whoAmI==0x70)return "MPU6500";
    return (whoAmI&0x7E)==0x68?"MPU6050":"UNKNOWN";
  }
  float ax=0,ay=0,az=0,gx=0,gy=0,gz=0,vx=0,vy=0,vz=0;
  uint32_t sampleMs=0,errors=0,nextMs=0,lastProgressMs=0;uint16_t stillSamples=0;
  bool read(uint8_t reg,uint8_t* out,uint8_t n){
    lastRegister=reg;
    Wire.beginTransmission(CanSatPins::MPU_ADDRESS);Wire.write(reg);
    wireError=Wire.endTransmission(false);if(wireError!=0)return false;
    if(Wire.requestFrom(uint8_t(CanSatPins::MPU_ADDRESS),n)!=n){wireError=255;while(Wire.available())Wire.read();return false;}
    for(unsigned i=0;i<n;++i)out[i]=Wire.read();
    return true;
  }
  bool begin(bool startup=false){
    present=gravityReady=false;stillSamples=0;whoAmI=0;initStage=1;
    lastProgressMs=millis();nextMs=lastProgressMs+100;
    if(!read(0x75,&whoAmI,1)){++errors;return false;}
    initStage=2;
    if((whoAmI&0x7E)!=0x68 && whoAmI!=0x70){++errors;return false;}
    initStage=3;
    libraryBus.clear();
    // init() has about30ms of library reset delays: startup only, never retry
    // it inside the live flight loop. Runtime recovery reapplies configuration.
    if(startup && !sensor.initialize(whoAmI)){libraryResult();++errors;return false;}
    sensor.setAccOffsets(xyzFloat{0,0,0});sensor.setGyrOffsets(xyzFloat{0,0,0});
    sensor.sleep(false);
    sensor.enableAccAxes(MPU6500_ENABLE_XYZ);sensor.enableGyrAxes(MPU6500_ENABLE_XYZ);
    sensor.enableGyrDLPF();sensor.setGyrDLPF(MPU6500_DLPF_6);
    sensor.setGyrRange(MPU6500_GYRO_RANGE_2000);
    sensor.setAccRange(MPU6500_ACC_RANGE_16G);
    if(whoAmI==0x70){sensor.enableAccDLPF(true);sensor.setAccDLPF(MPU6500_DLPF_6);}
    sensor.setSampleRateDivider(9);sensor.enableInterrupt(MPU6500_DATA_READY);
    if(!libraryResult()){++errors;return false;}
    // Verify the actual range/filter/rate registers before trusting conversions.
    uint8_t value=0;
    const uint8_t regs[]={0x1A,0x1B,0x1C,0x19,0x6B,0x6C,0x38};
    const uint8_t masks[]={7,0x1B,0x18,0xFF,0x40,0x3F,1};
    const uint8_t expected[]={6,0x18,0x18,9,0,0,1};
    for(unsigned i=0;i<sizeof(regs);++i)if(!read(regs[i],&value,1) || (value&masks[i])!=expected[i]){++errors;return false;}
    if(whoAmI==0x70 && (!read(0x1D,&value,1) || (value&15)!=6)){++errors;return false;}
    present=true;lastProgressMs=millis();nextMs=lastProgressMs+100;
    initStage=4;return true;
  }
  bool libraryResult(){
    lastRegister=libraryBus.error?libraryBus.errorRegister:libraryBus.reg;
    wireError=libraryBus.error;return wireError==0;
  }
  bool update(uint32_t now,float bx,float by,float bz){
    if(int32_t(now-nextMs)<0)return false;
    nextMs=now+10;
    if(!present){if(begin())return false;nextMs=now+5000;return false;}
    uint8_t ready=0;
    if(!read(0x3A,&ready,1)){fault();return false;}
    if(!(ready&1)){if(uint32_t(now-lastProgressMs)>1000)fault();return false;}
    libraryBus.clear();
    const xyzFloat g=sensor.getGValues();
    if(!libraryResult()){fault();return false;}
    const xyzFloat gyr=sensor.getGyrValues();
    if(!libraryResult()){fault();return false;}
    // autoOffsets() is intentionally not run: it blocks and assumes Z-up.
    // Existing CAL/flash offsets and orientation-aware host gravity remain.
    if(!isfinite(g.x)||!isfinite(g.y)||!isfinite(g.z)||!isfinite(gyr.x)||!isfinite(gyr.y)||!isfinite(gyr.z) ||
       fabsf(g.x)>=15.99609375f||fabsf(g.y)>=15.99609375f||fabsf(g.z)>=15.99609375f ||
       fabsf(gyr.x)>=1999.51171875f||fabsf(gyr.y)>=1999.51171875f||fabsf(gyr.z)>=1999.51171875f){fault();return false;}
    ax=g.x*9.80665f;ay=g.y*9.80665f;az=g.z*9.80665f;
    gx=gyr.x;gy=gyr.y;gz=gyr.z;
    const float norm=sqrtf(ax*ax+ay*ay+az*az),x=gx-bx,y=gy-by,z=gz-bz;
    const float dt=uint32_t(now-sampleMs)*0.001f;
    const bool still=norm>0.85f*9.80665f && norm<1.15f*9.80665f && fabsf(x)<5 && fabsf(y)<5 && fabsf(z)<5;
    if(!gravityReady){
      if(still){vx=ax/norm*9.80665f;vy=ay/norm*9.80665f;vz=az/norm*9.80665f;if(++stillSamples>=100)gravityReady=true;}
      else stillSamples=0;
    }else if(dt>0 && dt<=0.1f){
      const float k=dt*0.01745329252f;
      const float nx=vx+(z*vy-y*vz)*k,ny=vy+(x*vz-z*vx)*k,nz=vz+(y*vx-x*vy)*k;
      vx=nx;vy=ny;vz=nz;
      if(still){const float a=dt/(2+dt);vx+=a*(ax/norm*9.80665f-vx);vy+=a*(ay/norm*9.80665f-vy);vz+=a*(az/norm*9.80665f-vz);}
      const float g=sqrtf(vx*vx+vy*vy+vz*vz);
      if(isfinite(g) && g>0){vx*=9.80665f/g;vy*=9.80665f/g;vz*=9.80665f/g;}else gravityReady=false;
    }else {gravityReady=false;stillSamples=0;}
    sampleMs=lastProgressMs=now;return isfinite(norm) && norm<15*9.80665f;
  }
  void fault(){++errors;present=gravityReady=false;stillSamples=0;initStage=5;nextMs=millis()+5000;}
};
