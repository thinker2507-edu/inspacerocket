#pragma once
#include <stdint.h>

// Explicit USB bench maintenance only. Ordinary startup never requests erase.
// Hardware continues to erase internally; each service call does one status
// poll or at most one4KiB verification read. A failed/finished attempt stays
// locked until reboot, so the old journal can never write into a partial erase.
struct BootFlashErase {
  enum Phase : uint8_t { IDLE, ERASING, VERIFYING, DONE, FAILED };
  static constexpr uint32_t WINDOW_MS=60000, TIMEOUT_MS=120000;
  Phase phase=IDLE;
  uint32_t startedMs=0,lastPollMs=0,verifiedBytes=0,doneMs=0;
  const char* reason="IDLE";
  uint8_t buffer[4096]={};
  bool locked()const{return phase!=IDLE;}
  template<class Backend>
  bool request(Backend& io,uint32_t now,uint32_t bootMs,bool safe){
    if(locked()){reason="ALREADY_ATTEMPTED_REBOOT_REQUIRED";return false;}
    if(uint32_t(now-bootMs)>=WINDOW_MS){reason="BOOT_WINDOW_CLOSED_REBOOT_REQUIRED";return false;}
    if(!safe){reason="NEED_RECOVERED_UNARMED_PAD_OR_COMPLETED_MISSION_AND_IDLE_COMMANDS";return false;}
    if(!io.startChipErase()){reason="CHIP_BUSY_PROTECTED_UNAVAILABLE_OR_WRONG_ID";return false;}
    phase=ERASING;startedMs=lastPollMs=now;reason="ERASING";return true;
  }
  template<class Backend>
  void service(Backend& io,uint32_t now){
    if(phase!=ERASING && phase!=VERIFYING)return;
    if(uint32_t(now-startedMs)>=TIMEOUT_MS){phase=FAILED;reason="TIMEOUT_REBOOT_REQUIRED";return;}
    if(phase==ERASING){
      if(uint32_t(now-lastPollMs)<10)return;
      lastPollMs=now;
      if(io.ready()){phase=VERIFYING;reason="VERIFYING";}
      return;
    }
    uint32_t bytes=io.size()-verifiedBytes;
    if(bytes>sizeof(buffer))bytes=sizeof(buffer);
    if(!bytes || !io.read(verifiedBytes,buffer,bytes)){
      phase=FAILED;reason="VERIFY_READ_FAILED_REBOOT_REQUIRED";return;
    }
    for(uint32_t i=0;i<bytes;++i)if(buffer[i]!=0xFF){
      phase=FAILED;reason="NOT_FULLY_ERASED_REBOOT_REQUIRED";return;
    }
    verifiedBytes+=bytes;
    if(verifiedBytes==io.size()){phase=DONE;doneMs=now;reason="VERIFIED_RESTARTING";}
  }
};
